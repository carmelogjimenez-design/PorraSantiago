-- =================================================================
-- LA PORRA DE SANTIAGO — Sección "Pronósticos" (el cuadro de la peña)
-- Devuelve TODOS los pronósticos de TODOS los jugadores, pero SOLO
-- una vez ha pitado el primer partido del Mundial (anti-trampas).
-- Ejecutar en Supabase -> SQL Editor -> Run.
-- =================================================================

-- ¿Ha arrancado ya el Mundial? (el primer partido de grupos ha empezado)
create or replace function public.tournament_started()
returns boolean
language sql stable security definer set search_path = public
as $$
  select coalesce(min(kickoff_at) <= now(), false)
  from public.matches
  where group_id is not null;
$$;

grant execute on function public.tournament_started() to anon, authenticated;

-- Todos los pronósticos (solo si el Mundial ya ha arrancado)
create or replace function public.get_all_predictions()
returns table(user_id uuid, display_name text, match_id uuid, pred_home int, pred_away int)
language sql stable security definer set search_path = public
as $$
  select p.user_id, coalesce(pr.display_name, 'Jugador'), p.match_id, p.pred_home, p.pred_away
  from public.predictions p
  join public.profiles pr on pr.id = p.user_id
  where public.tournament_started();
$$;

grant execute on function public.get_all_predictions() to anon, authenticated;
